package problem233.textInverser

import java.awt._
import java.awt.event.{KeyEvent, KeyListener}
import javax.swing._

/**
  * @author Problem233
  * @version 1.0
  */
class TextInverser extends JFrame{

  private val input = new JTextArea()
  private val output = new JTextArea()
  private val label = new JLabel("↑反转前 反转后↓", SwingConstants.CENTER)
  private val vBox = Box.createVerticalBox()
  private val hBox = Box.createHorizontalBox()
  private val lay = new BorderLayout()
  private val contentPane = new JPanel()

  private val WIDTH = 500
  private val HEIGHT = 400
  private val TITLE = "332melborP yb 0.1v 器转反字文"

  setTitle(TITLE)
  setSize(WIDTH, HEIGHT)
  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)
  setContentPane(contentPane)
  setLayout(lay)

  private val screenSize = Toolkit.getDefaultToolkit().getScreenSize()
  val X = (screenSize.width - WIDTH) / 2
  val Y = (screenSize.height - HEIGHT) / 2
  setLocation(X, Y)

  private val scroll1 = new JScrollPane(input, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED)
  private val scroll2 = new JScrollPane(output, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED)

  hBox.add(Box.createHorizontalGlue())
  hBox.add(label)
  hBox.add(Box.createHorizontalGlue())

  vBox.add(scroll1)
  vBox.add(hBox)
  vBox.add(scroll2)

  contentPane.add(vBox, BorderLayout.CENTER)

  output.setEditable(false)

  input.addKeyListener(new KeyListener {
    override def keyTyped(e: KeyEvent): Unit = { }
    override def keyPressed(e: KeyEvent): Unit = { }
    override def keyReleased(e: KeyEvent): Unit = {
      output.setText(new StringBuffer(input.getText()).reverse().toString())
    }
  })

  UIManager.setLookAndFeel("org.jackhuang.hellominecraft.lookandfeel.HelloMinecraftLookAndFeel")
  SwingUtilities.updateComponentTreeUI(this)

}
