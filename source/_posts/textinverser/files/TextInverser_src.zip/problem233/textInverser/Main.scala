package problem233.textInverser

/**
  * @author Problem233
  * @version 1.0
  */
object Main extends App{
  private val textInverser = new TextInverser()
  textInverser.setVisible(true)
}
